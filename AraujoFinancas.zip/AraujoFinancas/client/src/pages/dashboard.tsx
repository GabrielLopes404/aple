import { MetricCard } from "@/components/metric-card";
import { ProgressRing } from "@/components/progress-ring";
import { CalendarWidget } from "@/components/calendar-widget";
import { 
  DollarSign, 
  TrendingUp, 
  TrendingDown, 
  Clock,
  Plus,
  Upload,
  FileText,
  Info
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const cashFlowData = [
  { month: "Jan", receitas: 45000, despesas: 32000 },
  { month: "Fev", receitas: 52000, despesas: 38000 },
  { month: "Mar", receitas: 48000, despesas: 35000 },
  { month: "Abr", receitas: 61000, despesas: 42000 },
  { month: "Mai", receitas: 55000, despesas: 39000 },
  { month: "Jun", receitas: 67000, despesas: 45000 },
];

const recentTransactions = [
  { id: 1, description: "Pagamento Cliente ABC", value: 5200, type: "receita", date: "2024-11-01" },
  { id: 2, description: "Fornecedor XYZ Ltda", value: -2800, type: "despesa", date: "2024-11-01" },
  { id: 3, description: "Serviço Consultoria", value: 3500, type: "receita", date: "2024-10-31" },
  { id: 4, description: "Aluguel Escritório", value: -4200, type: "despesa", date: "2024-10-30" },
  { id: 5, description: "Venda Produto Premium", value: 8900, type: "receita", date: "2024-10-30" },
];

export default function Dashboard() {
  return (
    <div className="flex-1 space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Bom dia, Gabriel.</h1>
          <p className="text-muted-foreground">Visão geral das suas finanças</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" data-testid="button-import-ofx">
            <Upload className="h-4 w-4 mr-2" />
            Importar OFX
          </Button>
          <Button data-testid="button-new-transaction">
            <Plus className="h-4 w-4 mr-2" />
            Nova Transação
          </Button>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          {/* Previsto/Realizado no Mês */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Previsto / realizado no mês</CardTitle>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  Novembro/2025 - Conta Principal
                  <Info className="h-4 w-4" />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <div className="flex justify-center">
                    <ProgressRing
                      progress={100}
                      color="hsl(var(--chart-2))"
                      label="Recebido"
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Recebido</span>
                      <span className="font-semibold font-mono text-success">R$ 80,00</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Falta</span>
                      <span className="font-semibold font-mono">R$ 0,00</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Previsto</span>
                      <span className="font-semibold font-mono">R$ 80,00</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex justify-center">
                    <ProgressRing
                      progress={100}
                      color="hsl(var(--destructive))"
                      label="Pago"
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Pago</span>
                      <span className="font-semibold font-mono text-destructive">R$ 80,00</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Falta</span>
                      <span className="font-semibold font-mono">R$ 0,00</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Previsto</span>
                      <span className="font-semibold font-mono">R$ 80,00</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Fluxo de Caixa */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Fluxo de caixa</CardTitle>
                <div className="text-sm text-muted-foreground">
                  Novembro/2025 - Conta Principal
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <span className="text-sm font-medium">R$ 1,00</span>
              </div>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={cashFlowData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="month" className="text-xs" />
                  <YAxis className="text-xs" hide />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '6px'
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="receitas" 
                    stroke="hsl(var(--chart-2))" 
                    strokeWidth={2}
                    dot={{ r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Comparativo */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Comparativo</CardTitle>
                <div className="text-sm text-muted-foreground">
                  Novembro/2025 - Conta Principal
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Recebimentos</span>
                    <span className="text-sm font-mono">-- % (R$ 0,00) ←</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div className="bg-success h-2 rounded-full" style={{ width: '75%' }} />
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Despesas</span>
                    <span className="text-sm font-mono">-- % (R$ 0,00) ←</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div className="bg-destructive h-2 rounded-full" style={{ width: '75%' }} />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Últimas Atualizações */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Últimas atualizações em transações</CardTitle>
                <Info className="h-4 w-4 text-muted-foreground" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <div className="w-48 h-48 mx-auto mb-4 bg-muted/30 rounded-lg flex items-center justify-center">
                  <FileText className="h-16 w-16 text-muted-foreground" />
                </div>
                <p className="text-muted-foreground">Nenhum histórico encontrado</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          {/* Conta Principal */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Conta Principal</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Saldo atual:</p>
                  <p className="text-2xl font-bold font-mono text-success" data-testid="balance-current">
                    R$ 0,00
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Previsão do mês:</p>
                  <p className="text-xl font-semibold font-mono">R$ 80,00</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Calendário */}
          <CalendarWidget />

          {/* Quick Stats */}
          <div className="grid grid-cols-2 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="h-4 w-4 text-success" />
                  <span className="text-xs text-muted-foreground">Receitas</span>
                </div>
                <p className="text-lg font-bold font-mono text-success">R$ 67.000</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingDown className="h-4 w-4 text-destructive" />
                  <span className="text-xs text-muted-foreground">Despesas</span>
                </div>
                <p className="text-lg font-bold font-mono text-destructive">R$ 45.000</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

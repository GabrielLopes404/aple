import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Download, Printer } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const dreData = [
  { 
    categoria: "Receita Operacional Bruta", 
    jan: 67000, 
    fev: 72000, 
    mar: 68000,
    nivel: 0,
    isBold: true
  },
  { 
    categoria: "Vendas de Produtos", 
    jan: 45000, 
    fev: 48000, 
    mar: 46000,
    nivel: 1,
    isBold: false
  },
  { 
    categoria: "Prestação de Serviços", 
    jan: 22000, 
    fev: 24000, 
    mar: 22000,
    nivel: 1,
    isBold: false
  },
  { 
    categoria: "(-) Deduções", 
    jan: -5360, 
    fev: -5760, 
    mar: -5440,
    nivel: 0,
    isBold: true
  },
  { 
    categoria: "Impostos sobre Vendas", 
    jan: -5360, 
    fev: -5760, 
    mar: -5440,
    nivel: 1,
    isBold: false
  },
  { 
    categoria: "= Receita Líquida", 
    jan: 61640, 
    fev: 66240, 
    mar: 62560,
    nivel: 0,
    isBold: true,
    highlight: true
  },
  { 
    categoria: "(-) Custos", 
    jan: -28000, 
    fev: -30000, 
    mar: -29000,
    nivel: 0,
    isBold: true
  },
  { 
    categoria: "Fornecedores", 
    jan: -18000, 
    fev: -19000, 
    mar: -18500,
    nivel: 1,
    isBold: false
  },
  { 
    categoria: "Materiais", 
    jan: -10000, 
    fev: -11000, 
    mar: -10500,
    nivel: 1,
    isBold: false
  },
  { 
    categoria: "= Lucro Bruto", 
    jan: 33640, 
    fev: 36240, 
    mar: 33560,
    nivel: 0,
    isBold: true,
    highlight: true
  },
  { 
    categoria: "(-) Despesas Operacionais", 
    jan: -17000, 
    fev: -18000, 
    mar: -17500,
    nivel: 0,
    isBold: true
  },
  { 
    categoria: "Salários e Encargos", 
    jan: -12000, 
    fev: -12000, 
    mar: -12000,
    nivel: 1,
    isBold: false
  },
  { 
    categoria: "Aluguel", 
    jan: -4200, 
    fev: -4200, 
    mar: -4200,
    nivel: 1,
    isBold: false
  },
  { 
    categoria: "Outras Despesas", 
    jan: -800, 
    fev: -1800, 
    mar: -1300,
    nivel: 1,
    isBold: false
  },
  { 
    categoria: "= Resultado Operacional (EBITDA)", 
    jan: 16640, 
    fev: 18240, 
    mar: 16060,
    nivel: 0,
    isBold: true,
    highlight: true
  },
];

export default function Relatorios() {
  return (
    <div className="flex-1 space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Relatórios</h1>
          <p className="text-muted-foreground">DRE e análises gerenciais</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" data-testid="button-print">
            <Printer className="h-4 w-4 mr-2" />
            Imprimir
          </Button>
          <Button variant="outline" data-testid="button-export-pdf">
            <Download className="h-4 w-4 mr-2" />
            Exportar PDF
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <CardTitle>Demonstração do Resultado do Exercício (DRE)</CardTitle>
            <div className="flex gap-2">
              <Select defaultValue="q1-2024">
                <SelectTrigger className="w-[180px]" data-testid="select-period">
                  <SelectValue placeholder="Período" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="q1-2024">1º Tri 2024</SelectItem>
                  <SelectItem value="q2-2024">2º Tri 2024</SelectItem>
                  <SelectItem value="q3-2024">3º Tri 2024</SelectItem>
                  <SelectItem value="q4-2024">4º Tri 2024</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[40%]">Categoria</TableHead>
                <TableHead className="text-right">Janeiro</TableHead>
                <TableHead className="text-right">Fevereiro</TableHead>
                <TableHead className="text-right">Março</TableHead>
                <TableHead className="text-right font-semibold">Total Trimestre</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {dreData.map((item, index) => {
                const total = item.jan + item.fev + item.mar;
                const paddingClass = item.nivel === 1 ? 'pl-8' : '';
                const fontClass = item.isBold ? 'font-semibold' : '';
                const bgClass = item.highlight ? 'bg-muted/50' : '';
                
                return (
                  <TableRow 
                    key={index} 
                    className={bgClass}
                    data-testid={`dre-row-${index}`}
                  >
                    <TableCell className={`${paddingClass} ${fontClass}`}>
                      {item.categoria}
                    </TableCell>
                    <TableCell className={`text-right font-mono ${fontClass}`}>
                      R$ {item.jan.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </TableCell>
                    <TableCell className={`text-right font-mono ${fontClass}`}>
                      R$ {item.fev.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </TableCell>
                    <TableCell className={`text-right font-mono ${fontClass}`}>
                      R$ {item.mar.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </TableCell>
                    <TableCell className={`text-right font-mono ${fontClass} ${item.highlight ? 'text-primary' : ''}`}>
                      R$ {total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Margem Bruta
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">54,6%</div>
            <p className="text-xs text-muted-foreground mt-1">
              Lucro Bruto / Receita Líquida
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Margem Operacional
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">26,9%</div>
            <p className="text-xs text-muted-foreground mt-1">
              EBITDA / Receita Líquida
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Resultado do Trimestre
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-success">
              R$ 50.940,00
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              EBITDA Total
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

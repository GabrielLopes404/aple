import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Plus, 
  Search, 
  MoreHorizontal,
  Edit,
  Trash,
  CheckCircle2,
  Filter
} from "lucide-react";
import { StatusBadge } from "@/components/status-badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

const mockContas = [
  {
    id: 1,
    descricao: "Pagamento Fornecedor ABC",
    categoria: "Fornecedores",
    valor: -5200.00,
    vencimento: "2024-11-15",
    status: "pendente" as const,
    tipo: "pagar"
  },
  {
    id: 2,
    descricao: "Recebimento Cliente XYZ",
    categoria: "Vendas",
    valor: 8900.00,
    vencimento: "2024-11-10",
    status: "pago" as const,
    tipo: "receber"
  },
  {
    id: 3,
    descricao: "Aluguel Escritório",
    categoria: "Despesas Fixas",
    valor: -4200.00,
    vencimento: "2024-11-05",
    status: "pago" as const,
    tipo: "pagar"
  },
  {
    id: 4,
    descricao: "Serviço Consultoria DEF",
    categoria: "Serviços",
    valor: 3500.00,
    vencimento: "2024-11-20",
    status: "agendado" as const,
    tipo: "receber"
  },
  {
    id: 5,
    descricao: "Fornecimento Materiais",
    categoria: "Fornecedores",
    valor: -2800.00,
    vencimento: "2024-11-08",
    status: "vencido" as const,
    tipo: "pagar"
  },
];

const categories = [
  { name: "Recebimentos", count: 2, color: "bg-success/10 text-success border-success/20" },
  { name: "Despesas fixas", count: 1, color: "bg-destructive/10 text-destructive border-destructive/20" },
  { name: "Despesas variáveis", count: 2, color: "bg-warning/10 text-warning border-warning/20" },
  { name: "Pessoas", count: 0, color: "bg-primary/10 text-primary border-primary/20" },
  { name: "Impostos", count: 0, color: "bg-chart-4/10 text-chart-4 border-chart-4/20" },
];

export default function Contas() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterTipo, setFilterTipo] = useState<string>("all");
  const [selectedMonth, setSelectedMonth] = useState("NOV/2025");

  const filteredContas = mockContas.filter(conta => {
    const matchesSearch = conta.descricao.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "all" || conta.status === filterStatus;
    const matchesTipo = filterTipo === "all" || conta.tipo === filterTipo;
    return matchesSearch && matchesStatus && matchesTipo;
  });

  const totals = {
    recebido: mockContas.filter(c => c.valor > 0 && c.status === 'pago').reduce((sum, c) => sum + c.valor, 0),
    aReceber: mockContas.filter(c => c.valor > 0 && c.status !== 'pago').reduce((sum, c) => sum + c.valor, 0),
    pago: mockContas.filter(c => c.valor < 0 && c.status === 'pago').reduce((sum, c) => sum + Math.abs(c.valor), 0),
    aPagar: mockContas.filter(c => c.valor < 0 && c.status !== 'pago').reduce((sum, c) => sum + Math.abs(c.valor), 0),
  };

  return (
    <div className="flex-1 space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Transações</h1>
          <p className="text-muted-foreground">Gerencie contas a pagar e receber</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" data-testid="button-filter">
            <Filter className="h-4 w-4 mr-2" />
            Filtrar
          </Button>
          <Button data-testid="button-new-transaction">
            <Plus className="h-4 w-4 mr-2" />
            Nova transação
          </Button>
        </div>
      </div>

      {/* Resumo */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Resultado previsto no mês</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold font-mono mb-4">R$ 1,00</div>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Recebido</span>
                <span className="font-semibold font-mono text-success">
                  {totals.recebido.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div className="bg-success h-2 rounded-full" style={{ width: '100%' }} />
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Previsto</span>
                <span className="font-mono">R$ 80,00</span>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Pago</span>
                <span className="font-semibold font-mono text-destructive">
                  {totals.pago.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div className="bg-destructive h-2 rounded-full" style={{ width: '100%' }} />
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Previsto</span>
                <span className="font-mono">R$ 80,00</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Filtros de Categoria */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        <Button
          variant="default"
          size="sm"
          className="flex-shrink-0"
          data-testid="filter-all-categories"
        >
          Todos
        </Button>
        {categories.map((cat) => (
          <Badge
            key={cat.name}
            variant="outline"
            className={`${cat.color} flex-shrink-0 cursor-pointer hover-elevate px-3 py-1.5`}
            data-testid={`filter-category-${cat.name.toLowerCase()}`}
          >
            {cat.name} ({cat.count})
          </Badge>
        ))}
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                data-testid="button-prev-month"
              >
                ‹
              </Button>
              <Badge variant="default" className="font-mono">
                {selectedMonth}
              </Badge>
              <Button
                variant="ghost"
                size="sm"
                data-testid="button-next-month"
              >
                ›
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Pesquisar..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9"
                  data-testid="input-search-transactions"
                />
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Data</TableHead>
                <TableHead>Descrição</TableHead>
                <TableHead>Recebido de</TableHead>
                <TableHead>Categoria</TableHead>
                <TableHead className="text-right">Valor</TableHead>
                <TableHead>Tipo pagamento</TableHead>
                <TableHead>Pago?</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredContas.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8}>
                    <div className="text-center py-12">
                      <div className="w-48 h-48 mx-auto mb-4 bg-muted/30 rounded-lg flex items-center justify-center">
                        <Plus className="h-16 w-16 text-muted-foreground" />
                      </div>
                      <p className="text-lg font-semibold mb-2">A lista está vazia</p>
                      <p className="text-sm text-muted-foreground mb-4">
                        Comece adicionando seu primeiro item
                      </p>
                      <Button data-testid="button-add-first">
                        <Plus className="h-4 w-4 mr-2" />
                        Adicionar
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                filteredContas.map((conta) => (
                  <TableRow key={conta.id} data-testid={`transaction-row-${conta.id}`}>
                    <TableCell className="font-mono text-sm">
                      {new Date(conta.vencimento).toLocaleDateString('pt-BR')}
                    </TableCell>
                    <TableCell className="font-medium">{conta.descricao}</TableCell>
                    <TableCell>-</TableCell>
                    <TableCell>
                      <Badge variant="outline">{conta.categoria}</Badge>
                    </TableCell>
                    <TableCell className={`text-right font-mono font-semibold ${
                      conta.valor > 0 ? 'text-success' : 'text-destructive'
                    }`}>
                      {conta.valor > 0 ? '+' : ''}R$ {Math.abs(conta.valor).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </TableCell>
                    <TableCell>-</TableCell>
                    <TableCell>
                      <StatusBadge status={conta.status} />
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" data-testid={`button-actions-${conta.id}`}>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem data-testid={`button-mark-paid-${conta.id}`}>
                            <CheckCircle2 className="h-4 w-4 mr-2" />
                            Marcar como Pago
                          </DropdownMenuItem>
                          <DropdownMenuItem data-testid={`button-edit-${conta.id}`}>
                            <Edit className="h-4 w-4 mr-2" />
                            Editar
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive" data-testid={`button-delete-${conta.id}`}>
                            <Trash className="h-4 w-4 mr-2" />
                            Excluir
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Upload, CheckCircle2, AlertCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const extratoImportado = [
  { id: 1, data: "2024-11-01", descricao: "PIX RECEBIDO - JOAO SILVA", valor: 5200, conciliado: true },
  { id: 2, data: "2024-11-01", descricao: "TED ENVIADA - ABC FORNEC", valor: -2800, conciliado: true },
  { id: 3, data: "2024-10-31", descricao: "PIX RECEBIDO - MARIA SANTOS", valor: 3500, conciliado: false },
  { id: 4, data: "2024-10-30", descricao: "BOLETO PAGTO - ALUGUEL", valor: -4200, conciliado: true },
];

const lancamentosSistema = [
  { id: 1, data: "2024-11-01", descricao: "Pagamento Cliente ABC", valor: 5200, conciliado: true },
  { id: 2, data: "2024-11-01", descricao: "Fornecedor XYZ Ltda", valor: -2800, conciliado: true },
  { id: 3, data: "2024-10-30", descricao: "Aluguel Escritório", valor: -4200, conciliado: true },
  { id: 4, data: "2024-10-25", descricao: "Serviço Consultoria", valor: 1800, conciliado: false },
];

export default function Conciliacao() {
  return (
    <div className="flex-1 space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Conciliação Bancária</h1>
          <p className="text-muted-foreground">Importe extratos e reconcilie lançamentos</p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Importar Extrato OFX</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center border-2 border-dashed rounded-lg p-12 hover-elevate">
            <Upload className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">Arraste um arquivo OFX aqui</h3>
            <p className="text-sm text-muted-foreground mb-4">ou clique para selecionar</p>
            <Input
              type="file"
              accept=".ofx"
              className="hidden"
              id="file-upload"
              data-testid="input-file-upload"
            />
            <Button asChild data-testid="button-upload-ofx">
              <label htmlFor="file-upload" className="cursor-pointer">
                Selecionar Arquivo
              </label>
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Conciliado
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-success">R$ 12.200,00</div>
            <p className="text-xs text-muted-foreground mt-1">
              3 de 4 transações
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Pendente de Conciliação
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-warning">R$ 5.300,00</div>
            <p className="text-xs text-muted-foreground mt-1">
              2 transações
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Taxa de Conciliação
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">75%</div>
            <p className="text-xs text-muted-foreground mt-1">
              Meta: 95%
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Extrato Bancário Importado</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data</TableHead>
                  <TableHead>Descrição</TableHead>
                  <TableHead className="text-right">Valor</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {extratoImportado.map((item) => (
                  <TableRow key={item.id} data-testid={`extrato-row-${item.id}`}>
                    <TableCell className="font-mono text-sm">
                      {new Date(item.data).toLocaleDateString('pt-BR')}
                    </TableCell>
                    <TableCell className="max-w-[200px] truncate">
                      {item.descricao}
                    </TableCell>
                    <TableCell className={`text-right font-mono font-semibold ${
                      item.valor > 0 ? 'text-success' : 'text-destructive'
                    }`}>
                      {item.valor > 0 ? '+' : ''}R$ {Math.abs(item.valor).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </TableCell>
                    <TableCell>
                      {item.conciliado ? (
                        <Badge variant="outline" className="bg-success/10 text-success border-success/20">
                          <CheckCircle2 className="h-3 w-3 mr-1" />
                          Conciliado
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20">
                          <AlertCircle className="h-3 w-3 mr-1" />
                          Pendente
                        </Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Lançamentos do Sistema</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data</TableHead>
                  <TableHead>Descrição</TableHead>
                  <TableHead className="text-right">Valor</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {lancamentosSistema.map((item) => (
                  <TableRow key={item.id} data-testid={`lancamento-row-${item.id}`}>
                    <TableCell className="font-mono text-sm">
                      {new Date(item.data).toLocaleDateString('pt-BR')}
                    </TableCell>
                    <TableCell className="max-w-[200px] truncate">
                      {item.descricao}
                    </TableCell>
                    <TableCell className={`text-right font-mono font-semibold ${
                      item.valor > 0 ? 'text-success' : 'text-destructive'
                    }`}>
                      {item.valor > 0 ? '+' : ''}R$ {Math.abs(item.valor).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </TableCell>
                    <TableCell>
                      {item.conciliado ? (
                        <Badge variant="outline" className="bg-success/10 text-success border-success/20">
                          <CheckCircle2 className="h-3 w-3 mr-1" />
                          Conciliado
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20">
                          <AlertCircle className="h-3 w-3 mr-1" />
                          Pendente
                        </Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
